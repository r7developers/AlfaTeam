..:: ALFA TEaM Shell ~ v4.0-Tesla ::..

Name filter in file manager for quick access
Pop-up terminal, ability to opening multiple terminals simultaneously and customizing
History of terminal commands
History of SQL connections for quicker access to database
Advanced editor that able to change font size and style and supporting multiple programming languages
Opening, managing and editing multiple files simultaneously
Configuring Grabber to find private scripts' configuration
Sorting by name, size and last modifying date of files and folders
Viewing all options as pop-up and multi-tab view for accessing options quickly
Right click enabled on files, folders and options
Archive Manager for managing compressed files
Capability to control and terminating each tab's proccess
Column Dumper for Database (for extracting specific data such as usernames and emails)
Fake page for CPanel and Direct Admin
Separating Database Manager and pop-up view of it, and capability to opening unlimited number of databases together without interference
Paging folders with a lot of files for faster loading
Bug fixes and other minor improvements.

[+] New features:

Redesigned Mysql Manager ~ Easy and powerfull !
Multiple File Manager ! ~ You can open multiple folders at the same time and manage them
In the editor [ control +s ] shortkey has been added for save files
Added [ ALFA_DATA ] as a Alfa Parent Folder. Thats mean all folders like: alfacgiapi, alfasymlinks, etc... they will be craeted in the ALFA_DATA folder.
Bug fixes and other minor improvements.

http://dl.solevisible.com/

#Alfa_Team

https://telegram.me/solevisible

Release Date: 2020-06-22